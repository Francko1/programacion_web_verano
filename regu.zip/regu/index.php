<?php

header("Location: views/site/inicio.php");

?>