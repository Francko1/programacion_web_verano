$(document).ready(
	function(){
		

	}
);